---------------------------------------------------
-- DidiSoft ORA_NET - Internet communication for PL/SQL
-- Copyright (c) DidiSoft Inc Eood, 2006-2019 
---------------------------------------------------

create or replace package ORA_NET as

--------------------------------------------
-- CONSTANTS
--------------------------------------------

-- Order files by name ascending
SUCCESS CONSTANT INTEGER := 0;
-- Order files by name descending
ERROR CONSTANT INTEGER := 1;

--------------------------------------------
-- Subprograms
--------------------------------------------
--
-- Retrieves remote resources via HTTP(S) 
--
function WGET(url varchar2) return BLOB
as language JAVA
NAME 'didisoft.OraNET.wget(java.lang.String) return oracle.sql.BLOB';

--
-- Retrieves remote resources via HTTP(S) 
-- 
--
function WGET(url varchar2, destination OUT BLOB, error_msg OUT VARCHAR2) return PLS_INTEGER
as language JAVA
NAME 'didisoft.OraNET.wget(java.lang.String, oracle.sql.BLOB[], java.lang.String[]) return int';

END ORA_NET;
/
