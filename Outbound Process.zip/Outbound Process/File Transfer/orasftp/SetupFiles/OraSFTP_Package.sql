---------------------------------------------------
-- DidiSoft OraSFTP - SFTP communication for PL/SQL
-- Copyright (c) DidiSoft Inc Eood, 2006-2021
---------------------------------------------------
create or replace type ORA_SFTP_FILES_LIST is table of varchar2(2000);
/

create or replace type ORA_SFTP_FILES_LIST_EX is table of VARCHAR2(1);
/

create or replace type ORA_SFTP_FILE as object (
 FileName VARCHAR(255),
 FileSize NUMBER,
 FileTime DATE,
 FileType NUMBER
); 
/

create or replace type ORA_SFTP_FILES_LIST_EX is table of ORA_SFTP_FILE;
/

-----------------------------------
-- Proxy server settings
-----------------------------------
create or replace type ORA_SFTP_HTTP_PROXY as object (
 Address VARCHAR(255),
 Port NUMBER,
 Username VARCHAR(255),
 Password VARCHAR(255),
 AdditionalHeaders VARCHAR(2000)
); 
/

---------------------------------------------------
create or replace package ORA_SFTP as

--------------------------------------------
-- CONSTANTS
--------------------------------------------
-- Directory names separator, 
-- can be used to concatenate directory names to form a file path
SFTP_DIR_SEPARATOR CONSTANT CHAR(1) := '/';

ENCODING_UTF8 CONSTANT VARCHAR2(255) := 'UTF-8';
ENCODING_UTF16 CONSTANT VARCHAR2(255) := 'UTF-16';
ENCODING_UTF32 CONSTANT VARCHAR2(255) := 'UTF-32';

-- Order files by name ascending
ORDER_NAME_ASC CONSTANT INTEGER := 1;
-- Order files by name descending
ORDER_NAME_DESC CONSTANT INTEGER := 2;
-- Order files by size ascending
ORDER_SIZE_ASC CONSTANT INTEGER := 3;
-- Order files by size descending
ORDER_SIZE_DESC CONSTANT INTEGER := 4;
-- Order files by time ascending
ORDER_DATE_ASC CONSTANT INTEGER := 5;
-- Order files by time descending
ORDER_DATE_DESC CONSTANT INTEGER := 6;

-- Regular file
FILE_TYPE_FILE CONSTANT INTEGER := 1;
-- Folder
FILE_TYPE_DIRECTORY CONSTANT INTEGER := 2;
-- Symbolic link
FILE_TYPE_SYMLINK CONSTANT INTEGER := 3;

-- File Permissions
PERMISSION_OWNER_READ    CONSTANT INTEGER := 256; -- owner has read permission
PERMISSION_OWNER_WRITE   CONSTANT INTEGER  := 128; -- owner has write permission
PERMISSION_OWNER_EXEC    CONSTANT INTEGER := 64; -- owner has execute permission
PERMISSION_GROUP_READ    CONSTANT INTEGER := 32; -- group has read permission
PERMISSION_GROUP_WRITE    CONSTANT INTEGER := 16; -- group has write permission
PERMISSION_GROUP_EXEC    CONSTANT INTEGER := 8; -- group has execute permission
PERMISSION_OTHERS_READ    CONSTANT INTEGER := 4; -- others have read permission
PERMISSION_OTHERS_WRITE    CONSTANT INTEGER := 2; -- others have write permission
PERMISSION_OTHERS_EXEC    CONSTANT INTEGER := 1; -- others have execute permission


--------------------------------------------
-- Printing low level debug information 
--------------------------------------------
procedure SET_DEBUG(debug BOOLEAN)
as language JAVA
NAME 'didisoft.OraSFTP.setDebug(boolean)';

function VERSION return VARCHAR2
as language JAVA
NAME 'didisoft.OraSFTP.getVersion() return String';

function IS_TRIAL_VERSION return PLS_INTEGER
as language JAVA
NAME 'didisoft.OraSFTP.isTrialVersion() return int';

procedure SET_BUFFER_SIZE(buffer_size PLS_INTEGER)
as language JAVA
NAME 'didisoft.OraSFTP.setBufferSize(int)';

function GET_BUFFER_SIZE return PLS_INTEGER
as language JAVA
NAME 'didisoft.OraSFTP.getBufferSize() return int';

-------------------
-- Connect
-------------------
function CONNECT_HOST(host varchar2, port PLS_INTEGER, username varchar2, key_data BLOB, key_password varchar2) return NUMBER
as language JAVA
NAME 'didisoft.OraSFTP.connect(java.lang.String, int, java.lang.String, oracle.sql.BLOB, java.lang.String) return long';

function CONNECT_HOST(host varchar2, username varchar2, key_data BLOB, key_password varchar2) return NUMBER
as language JAVA
NAME 'didisoft.OraSFTP.connect(java.lang.String, java.lang.String, oracle.sql.BLOB, java.lang.String) return long';

function CONNECT_HOST(host varchar2, port PLS_INTEGER, username varchar2, password varchar2) return NUMBER
as language JAVA
NAME 'didisoft.OraSFTP.connect(java.lang.String, int, java.lang.String, java.lang.String) return long';

function CONNECT_HOST(host varchar2, username varchar2, password varchar2) return NUMBER
as language JAVA
NAME 'didisoft.OraSFTP.connect(java.lang.String, java.lang.String, java.lang.String) return long';

-------------------
-- Connect with Timeout
-------------------

function CONNECT_HOST(host varchar2, port PLS_INTEGER, username varchar2, key_data BLOB, key_password varchar2, connection_timeout PLS_INTEGER, read_timeout PLS_INTEGER) return NUMBER
as language JAVA
NAME 'didisoft.OraSFTP.connect(java.lang.String, int, java.lang.String, oracle.sql.BLOB, java.lang.String, int, int) return long';

function CONNECT_HOST(host varchar2, username varchar2, key_data BLOB, key_password varchar2, connection_timeout PLS_INTEGER, read_timeout PLS_INTEGER) return NUMBER
as language JAVA
NAME 'didisoft.OraSFTP.connect(java.lang.String, java.lang.String, oracle.sql.BLOB, java.lang.String, int, int) return long';

function CONNECT_HOST(host varchar2, port PLS_INTEGER, username varchar2, password varchar2, connection_timeout PLS_INTEGER, read_timeout PLS_INTEGER) return NUMBER
as language JAVA
NAME 'didisoft.OraSFTP.connect(java.lang.String, int, java.lang.String, java.lang.String, int, int) return long';

function CONNECT_HOST(host varchar2, username varchar2, password varchar2, connection_timeout PLS_INTEGER, read_timeout PLS_INTEGER) return NUMBER
as language JAVA
NAME 'didisoft.OraSFTP.connect(java.lang.String, java.lang.String, java.lang.String, int, int) return long';

--------------------------------------
-- Connect with both key and password
--------------------------------------

function CONNECT_WITH_KEY_AND_PASSWORD(host varchar2, port PLS_INTEGER, username varchar2, password varchar2, key_data BLOB, key_password varchar2, connection_timeout PLS_INTEGER, read_timeout PLS_INTEGER) return NUMBER
as language JAVA
NAME 'didisoft.OraSFTP.connectWithKeyAndPass(java.lang.String, int, java.lang.String, java.lang.String, oracle.sql.BLOB, java.lang.String, int, int) return long';

function CONNECT_WITH_KEY_AND_PASSWORD(host varchar2, port PLS_INTEGER, username varchar2, password varchar2, key_data BLOB, key_password varchar2) return NUMBER
as language JAVA
NAME 'didisoft.OraSFTP.connectWithKeyAndPass(java.lang.String, int, java.lang.String, java.lang.String, oracle.sql.BLOB, java.lang.String) return long';

-------------------------------------
-- Proxy server connections
-------------------------------------

function CONNECT_HOST_PROXY(host varchar2, port PLS_INTEGER, username varchar2, key_data BLOB, key_password varchar2, proxy ORA_SFTP_HTTP_PROXY) return NUMBER
as language JAVA
NAME 'didisoft.OraSFTP.connectProxy(java.lang.String, int, java.lang.String, oracle.sql.BLOB, java.lang.String, java.sql.Struct) return long';

function CONNECT_HOST_PROXY(host varchar2, port PLS_INTEGER, username varchar2, password varchar2, proxy ORA_SFTP_HTTP_PROXY) return NUMBER
as language JAVA
NAME 'didisoft.OraSFTP.connectProxy(java.lang.String, int, java.lang.String, java.lang.String, java.sql.Struct) return long';

function CONNECT_HOST_PROXY(host varchar2, port PLS_INTEGER, username varchar2, key_data BLOB, key_password varchar2, connection_timeout PLS_INTEGER, read_timeout PLS_INTEGER, proxy ORA_SFTP_HTTP_PROXY) return NUMBER
as language JAVA
NAME 'didisoft.OraSFTP.connectProxy(java.lang.String, int, java.lang.String, oracle.sql.BLOB, java.lang.String, int, int, java.sql.Struct) return long';

function CONNECT_HOST_PROXY(host varchar2, port PLS_INTEGER, username varchar2, password varchar2, connection_timeout PLS_INTEGER, read_timeout PLS_INTEGER, proxy ORA_SFTP_HTTP_PROXY) return NUMBER
as language JAVA
NAME 'didisoft.OraSFTP.connectProxy(java.lang.String, int, java.lang.String, java.lang.String, int, int, java.sql.Struct) return long';

function CONNECT_WITH_KEY_AND_PASS_PROXY(host varchar2, port PLS_INTEGER, username varchar2, password varchar2, key_data BLOB, key_password varchar2, connection_timeout PLS_INTEGER, read_timeout PLS_INTEGER, proxy ORA_SFTP_HTTP_PROXY) return NUMBER
as language JAVA
NAME 'didisoft.OraSFTP.connectWithKeyAndPassProxy(java.lang.String, int, java.lang.String, java.lang.String, oracle.sql.BLOB, java.lang.String, int, int, java.sql.Struct) return long';

function CONNECT_WITH_KEY_AND_PASS_PROXY(host varchar2, port PLS_INTEGER, username varchar2, password varchar2, key_data BLOB, key_password varchar2, proxy ORA_SFTP_HTTP_PROXY) return NUMBER
as language JAVA
NAME 'didisoft.OraSFTP.connectWithKeyAndPassProxy(java.lang.String, int, java.lang.String, java.lang.String, oracle.sql.BLOB, java.lang.String, java.sql.Struct) return long';

-------------------
-- Disconnect
-------------------

procedure DISCONNECT_HOST(connection_id NUMBER)
as language JAVA
NAME 'didisoft.OraSFTP.disconnect(long)';

-------------------
-- SSH
-------------------
function SSH_EXECUTE(connection_id NUMBER, command varchar2) return VARCHAR2
as language JAVA
NAME 'didisoft.OraSFTP.execSshCommand(long, java.lang.String) return java.lang.String';

-------------------
-- Current folder
-------------------
function PWD(connection_id NUMBER) return VARCHAR2
as language JAVA
NAME 'didisoft.OraSFTP.getCurrentDirectory(long) return java.lang.String';

function CURRENT_DIRECTORY(connection_id NUMBER) return VARCHAR2
as language JAVA
NAME 'didisoft.OraSFTP.getCurrentDirectory(long) return java.lang.String';

-- Same as CD but returns TRUE on success and FALSE if there is no such directory
function CHDIR(connection_id NUMBER, remote_dir_name varchar2) return BOOLEAN
as language JAVA
NAME 'didisoft.OraSFTP.changeDirectory2(long, java.lang.String) return boolean';

procedure CD(connection_id NUMBER, remote_dir_name varchar2)
as language JAVA
NAME 'didisoft.OraSFTP.changeDirectory(long, java.lang.String)';

procedure CD_UP(connection_id NUMBER)
as language JAVA
NAME 'didisoft.OraSFTP.changeDirectoryUp(long)';

-------------------
-- List
-------------------
function LS(connection_id NUMBER, remote_dir_name varchar2) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.list(long, java.lang.String) return oracle.sql.Array';

function LS(connection_id NUMBER, remote_dir_name varchar2, ordering PLS_INTEGER) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.list(long, java.lang.String, int) return oracle.sql.Array';

function LS(connection_id NUMBER, remote_dir_name varchar2, ordering PLS_INTEGER, file_mask varchar2) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.list(long, java.lang.String, int, java.lang.String) return oracle.sql.Array';

function LIST(connection_id NUMBER) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.list(long) return oracle.sql.Array';

function LIST(connection_id NUMBER, ordering PLS_INTEGER) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.list(long, int) return oracle.sql.Array';

function LIST(connection_id NUMBER, ordering PLS_INTEGER, file_mask varchar2) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.list(long, int, java.lang.String) return oracle.sql.Array';

function LIST(connection_id NUMBER, remote_dir_name varchar2) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.list(long, java.lang.String) return oracle.sql.Array';

function LIST(connection_id NUMBER, remote_dir_name varchar2, ordering PLS_INTEGER) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.list(long, java.lang.String, int) return oracle.sql.Array';

function LIST(connection_id NUMBER, remote_dir_name varchar2, ordering PLS_INTEGER, file_mask varchar2) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.list(long, java.lang.String, int, String) return oracle.sql.Array';

-------------------
-- List Extended
-------------------
function LIST_EX(connection_id NUMBER) return ORA_SFTP_FILES_LIST_EX
as language JAVA
NAME 'didisoft.OraSFTP.listEx(long) return oracle.sql.Array';

function LIST_EX(connection_id NUMBER, ordering PLS_INTEGER) return ORA_SFTP_FILES_LIST_EX
as language JAVA
NAME 'didisoft.OraSFTP.listEx(long, int) return oracle.sql.Array';

function LIST_EX(connection_id NUMBER, ordering PLS_INTEGER, file_mask varchar2) return ORA_SFTP_FILES_LIST_EX
as language JAVA
NAME 'didisoft.OraSFTP.listEx(long, int, java.lang.String) return oracle.sql.Array';

function LIST_EX(connection_id NUMBER, remote_dir_name varchar2) return ORA_SFTP_FILES_LIST_EX
as language JAVA
NAME 'didisoft.OraSFTP.listEx(long, java.lang.String) return oracle.sql.Array';

function LIST_EX(connection_id NUMBER, remote_dir_name varchar2, ordering PLS_INTEGER) return ORA_SFTP_FILES_LIST_EX
as language JAVA
NAME 'didisoft.OraSFTP.listEx(long, java.lang.String, int) return oracle.sql.Array';

function LIST_EX(connection_id NUMBER, remote_dir_name varchar2, ordering PLS_INTEGER, file_mask varchar2) return ORA_SFTP_FILES_LIST_EX
as language JAVA
NAME 'didisoft.OraSFTP.listEx(long, java.lang.String, int, java.lang.String) return oracle.sql.Array';

-------------------
-- List Files
-------------------
function LIST_FILES(connection_id NUMBER) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.listFiles(long) return oracle.sql.Array';

function LIST_FILES(connection_id NUMBER, ordering PLS_INTEGER, file_mask varchar2) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.listFiles(long, int, java.lang.String) return oracle.sql.Array';

function LIST_FILES(connection_id NUMBER, remote_dir_name varchar2) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.listFiles(long, java.lang.String) return oracle.sql.Array';

function LIST_FILES(connection_id NUMBER, remote_dir_name varchar2, ordering PLS_INTEGER, file_mask varchar2) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.listFiles(long, java.lang.String, int, java.lang.String) return oracle.sql.Array';
-------------------
-- List Files Extended
-------------------
function LIST_FILES_EX(connection_id NUMBER) return ORA_SFTP_FILES_LIST_EX
as language JAVA
NAME 'didisoft.OraSFTP.listFilesEx(long) return oracle.sql.Array';

function LIST_FILES_EX(connection_id NUMBER, ordering PLS_INTEGER, file_mask varchar2) return ORA_SFTP_FILES_LIST_EX
as language JAVA
NAME 'didisoft.OraSFTP.listFilesEx(long, int, java.lang.String) return oracle.sql.Array';

function LIST_FILES_EX(connection_id NUMBER, remote_dir_name varchar2) return ORA_SFTP_FILES_LIST_EX
as language JAVA
NAME 'didisoft.OraSFTP.listFilesEx(long, java.lang.String) return oracle.sql.Array';

function LIST_FILES_EX(connection_id NUMBER, remote_dir_name varchar2, ordering PLS_INTEGER, file_mask varchar2) return ORA_SFTP_FILES_LIST_EX
as language JAVA
NAME 'didisoft.OraSFTP.listFilesEx(long, java.lang.String, int, java.lang.String) return oracle.sql.Array';

-------------------
-- List Dirs
-------------------
function LIST_DIRS(connection_id NUMBER) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.listDirs(long) return oracle.sql.Array';

function LIST_DIRS(connection_id NUMBER, ordering PLS_INTEGER, file_mask varchar2) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.listDirs(long, int, java.lang.String) return oracle.sql.Array';

function LIST_DIRS(connection_id NUMBER, remote_dir_name varchar2) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.listDirs(long, java.lang.String) return oracle.sql.Array';

function LIST_DIRS(connection_id NUMBER, remote_dir_name varchar2, ordering PLS_INTEGER, file_mask varchar2) return ORA_SFTP_FILES_LIST
as language JAVA
NAME 'didisoft.OraSFTP.listDirs(long, java.lang.String, int, java.lang.String) return oracle.sql.Array';

-------------------
-- List Directories Extended
-------------------
function LIST_DIRS_EX(connection_id NUMBER) return ORA_SFTP_FILES_LIST_EX
as language JAVA
NAME 'didisoft.OraSFTP.listDirsEx(long) return oracle.sql.Array';

function LIST_DIR_EX(connection_id NUMBER, remote_dir_name varchar2) return ORA_SFTP_FILES_LIST_EX
as language JAVA
NAME 'didisoft.OraSFTP.listDirsEx(long, java.lang.String) return oracle.sql.Array';

function LIST_DIRS_EX(connection_id NUMBER, ordering PLS_INTEGER) return ORA_SFTP_FILES_LIST_EX
as language JAVA
NAME 'didisoft.OraSFTP.listDirsEx(long, int) return oracle.sql.Array';

function LIST_DIRS_EX(connection_id NUMBER, remote_dir_name varchar2, ordering PLS_INTEGER) return ORA_SFTP_FILES_LIST_EX
as language JAVA
NAME 'didisoft.OraSFTP.listDirsEx(long, java.lang.String, int) return oracle.sql.Array';

function LIST_DIRS_EX(connection_id NUMBER, ordering PLS_INTEGER, file_mask varchar2) return ORA_SFTP_FILES_LIST_EX
as language JAVA
NAME 'didisoft.OraSFTP.listDirsEx(long, int, java.lang.String) return oracle.sql.Array';

function LIST_DIRS_EX(connection_id NUMBER, remote_dir_name varchar2, ordering PLS_INTEGER, file_mask varchar2) return ORA_SFTP_FILES_LIST_EX
as language JAVA
NAME 'didisoft.OraSFTP.listDirsEx(long, java.lang.String, int, java.lang.String) return oracle.sql.Array';

-------------------
-- Upload / Download
-------------------
procedure PUT(connection_id NUMBER, data BLOB, remote_file_name VARCHAR2)
as language JAVA
NAME 'didisoft.OraSFTP.upload(long, oracle.sql.BLOB, java.lang.String)';

procedure PUT(connection_id NUMBER, data BLOB, remote_file_name VARCHAR2, buffer_size PLS_INTEGER)
as language JAVA
NAME 'didisoft.OraSFTP.upload(long, oracle.sql.BLOB, java.lang.String, int)';

procedure UPLOAD(connection_id NUMBER, data BLOB, remote_file_name VARCHAR2)
as language JAVA
NAME 'didisoft.OraSFTP.upload(long, oracle.sql.BLOB, java.lang.String)';

procedure UPLOAD(connection_id NUMBER, data BLOB, remote_file_name VARCHAR2, buffer_size PLS_INTEGER)
as language JAVA
NAME 'didisoft.OraSFTP.upload(long, oracle.sql.BLOB, java.lang.String, int)';

function GET(connection_id NUMBER, remote_file_name VARCHAR2) return BLOB
as language JAVA
NAME 'didisoft.OraSFTP.download(long, java.lang.String) return oracle.sql.BLOB';

function DOWNLOAD(connection_id NUMBER, remote_file_name VARCHAR2) return BLOB
as language JAVA
NAME 'didisoft.OraSFTP.download(long, java.lang.String) return oracle.sql.BLOB';

procedure UPLOAD_CLOB(connection_id NUMBER, data CLOB, remote_file_name VARCHAR2)
as language JAVA
NAME 'didisoft.OraSFTP.uploadClob(long, oracle.sql.CLOB, java.lang.String)';

procedure UPLOAD_CLOB(connection_id NUMBER, data CLOB, remote_file_name VARCHAR2, buffer_size PLS_INTEGER)
as language JAVA
NAME 'didisoft.OraSFTP.uploadClob(long, oracle.sql.CLOB, java.lang.String, int)';

procedure UPLOAD_CLOB(connection_id NUMBER, data CLOB, remote_file_name VARCHAR2, charset VARCHAR2)
as language JAVA
NAME 'didisoft.OraSFTP.uploadClob(long, oracle.sql.CLOB, java.lang.String, java.lang.String)';

procedure UPLOAD_CLOB(connection_id NUMBER, data CLOB, remote_file_name VARCHAR2, buffer_size PLS_INTEGER, charset VARCHAR2)
as language JAVA
NAME 'didisoft.OraSFTP.uploadClob(long, oracle.sql.CLOB, java.lang.String, int, java.lang.String)';

function DOWNLOAD_CLOB(connection_id NUMBER, remote_file_name VARCHAR2, charset VARCHAR2) return CLOB
as language JAVA
NAME 'didisoft.OraSFTP.downloadClob(long, java.lang.String, java.lang.String) return oracle.sql.CLOB';

----------------------------------------
-- SCP (Secure Copy) Upload / Download
----------------------------------------

procedure SCP_UPLOAD(connection_id NUMBER, data BLOB, remote_file_name VARCHAR2)
as language JAVA
NAME 'didisoft.OraSFTP.scpUpload(long, oracle.sql.BLOB, java.lang.String)';

function SCP_DOWNLOAD(connection_id NUMBER, remote_file_name VARCHAR2) return BLOB
as language JAVA
NAME 'didisoft.OraSFTP.scpDownload(long, java.lang.String) return oracle.sql.BLOB';

------------------
-- Other OP
------------------
procedure RENAME(connection_id NUMBER, old_item_name VARCHAR2, new_item_name VARCHAR2)
as language JAVA
NAME 'didisoft.OraSFTP.rename(long, java.lang.String, java.lang.String)';

procedure RM(connection_id NUMBER, remote_file_name VARCHAR2)
as language JAVA
NAME 'didisoft.OraSFTP.delete(long, java.lang.String)';

procedure DELETE(connection_id NUMBER, remote_file_name VARCHAR2)
as language JAVA
NAME 'didisoft.OraSFTP.delete(long, java.lang.String)';

procedure RMDIR(connection_id NUMBER, remote_dir_name VARCHAR2)
as language JAVA
NAME 'didisoft.OraSFTP.deleteDir(long, java.lang.String)';

procedure DELETE_DIR(connection_id NUMBER, remote_dir_name VARCHAR2)
as language JAVA
NAME 'didisoft.OraSFTP.deleteDir(long, java.lang.String)';

procedure CREATE_DIR(connection_id NUMBER, remote_dir_name VARCHAR2)
as language JAVA
NAME 'didisoft.OraSFTP.createDir(long, java.lang.String)';

function EXISTS(connection_id NUMBER, remote_file_name varchar2) return BOOLEAN
as language JAVA
NAME 'didisoft.OraSFTP.exists(long, java.lang.String) return boolean';

function IS_DIRECTORY(connection_id NUMBER, remote_file_name varchar2) return BOOLEAN
as language JAVA
NAME 'didisoft.OraSFTP.isDirectory(long, java.lang.String) return boolean';

function IS_FILE(connection_id NUMBER, remote_file_name varchar2) return BOOLEAN
as language JAVA
NAME 'didisoft.OraSFTP.isFile(long, java.lang.String) return boolean';

function FILE_SIZE(connection_id NUMBER, remote_file_name varchar2) return PLS_INTEGER
as language JAVA
NAME 'didisoft.OraSFTP.fileSize(long, java.lang.String) return long';

function LAST_MODIFIED(connection_id NUMBER, remote_file_name varchar2) return DATE
as language JAVA
NAME 'didisoft.OraSFTP.lastModified(long, java.lang.String) return oracle.sql.DATE';

function LAST_MODIFIED_TIME(connection_id NUMBER, remote_file_name varchar2) return TIMESTAMP
as language JAVA
NAME 'didisoft.OraSFTP.lastModifiedTime(long, java.lang.String) return oracle.sql.TIMESTAMP';

procedure CHGRP(connection_id NUMBER, remote_file_name varchar2, GID NUMBER)
as language JAVA
NAME 'didisoft.OraSFTP.chgrp(long, java.lang.String, java.lang.Integer)';

procedure CHANGE_GROUP(connection_id NUMBER, remote_file_name varchar2, GID NUMBER)
as language JAVA
NAME 'didisoft.OraSFTP.chgrp(long, java.lang.String, java.lang.Integer)';

procedure CHMOD(connection_id NUMBER, remote_file_name varchar2, permission PLS_INTEGER)
as language JAVA
NAME 'didisoft.OraSFTP.chmod(long, java.lang.String, int)';

procedure CHANGE_MODE(connection_id NUMBER, remote_file_name varchar2, permission PLS_INTEGER)
as language JAVA
NAME 'didisoft.OraSFTP.chmod(long, java.lang.String, int)';

procedure TOUCH(connection_id NUMBER, remote_file_name varchar2)
as language JAVA
NAME 'didisoft.OraSFTP.touch(long, java.lang.String)';

procedure TOUCH(connection_id NUMBER, remote_file_name varchar2, set_time TIMESTAMP)
as language JAVA
NAME 'didisoft.OraSFTP.touch(long, java.lang.String, oracle.sql.TIMESTAMP)';

procedure TOUCH_LOCAL(local_file_name varchar2)
as language JAVA
NAME 'didisoft.OraSFTP.touchLocal(java.lang.String)';

procedure TOUCH_LOCAL(local_file_name varchar2, set_time TIMESTAMP)
as language JAVA
NAME 'didisoft.OraSFTP.touchLocal(java.lang.String, oracle.sql.TIMESTAMP)';

END ORA_SFTP;
/
