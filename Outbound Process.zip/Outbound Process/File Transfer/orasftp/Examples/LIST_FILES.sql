declare
  files ORA_SFTP_FILES_LIST;
  connection_id number;  
  private_key_handle BFILE;
  private_key BLOB;  
  private_key_password VARCHAR2(500);  
begin
    DBMS_LOB.createtemporary(PRIVATE_KEY, true);
    private_key_handle := BFILENAME('SSH_KEYS_DIR', 'didisoft.txt'); -- directory name must be Upper case
    DBMS_LOB.OPEN(private_key_handle, DBMS_LOB.LOB_READONLY);
    DBMS_LOB.LoadFromFile( private_key, private_key_handle, DBMS_LOB.GETLENGTH(private_key_handle) );
    DBMS_LOB.CLOSE(private_key_handle);
    private_key_password := 'DiDiSoftPassPhrase!';

    connection_id := ORA_SFTP.CONNECT_HOST('localhost', 22, 'nasko', private_key, 'DiDiSoftPassPhrase!');
  
    files := ORA_SFTP.LIST_FILES(connection_id, '.');  
    
    -- print the listed file names   
    for i in files.first .. files.last loop
     dbms_output.put_line('file(' || i || ') = ' || files(i));
    end loop;
  
    ORA_SFTP.DISCONNECT_HOST(connection_id);  
end;
/
