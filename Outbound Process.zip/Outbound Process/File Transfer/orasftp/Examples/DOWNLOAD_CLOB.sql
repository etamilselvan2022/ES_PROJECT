---------------------------------------------------
-- DidiSoft OraSFTP - SFTP communication for PL/SQL
-- DOWNLOAD_CLOB.sql
-- Copyright (c) DidiSoft Inc Eood, 2006-2021 
---------------------------------------------------
declare 
  connection_id number;
  private_key_handle BFILE;
  private_key BLOB;  
  private_key_password VARCHAR2(500);  
  
  downloaded_text CLOB;
begin
    DBMS_LOB.createtemporary(PRIVATE_KEY, true);
    private_key_handle := BFILENAME('ORACLE_HOME', 'private_sshcom_no_pass.txt'); -- directory name must be Upper case
    DBMS_LOB.OPEN(private_key_handle, DBMS_LOB.LOB_READONLY);
    DBMS_LOB.LoadFromFile( private_key, private_key_handle, DBMS_LOB.GETLENGTH(private_key_handle) );
    DBMS_LOB.CLOSE(private_key_handle);
    private_key_password := '';
  
    connection_id := ORA_SFTP.CONNECT_HOST('localhost', 22, 'nasko', private_key, private_key_password);
  
    downloaded_text := ORA_SFTP.DOWNLOAD_CLOB(connection_id, 'cdata3.txt');
    
    insert into recipients(name, note)
    values('cdata3.txt', downloaded_text);
    
    ORA_SFTP.DISCONNECT_HOST(connection_id);
end;
/

commit work;
