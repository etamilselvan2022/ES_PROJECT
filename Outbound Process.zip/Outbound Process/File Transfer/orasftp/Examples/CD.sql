--------------------------------
-- CD.sql
--
-- SFTP change directory example
--
-- Copyright (c) DidiSoft Inc, 2018
--------------------------------
declare 
  files ORA_SFTP_FILES_LIST;
  connection_id number;  
  private_key_handle BFILE;
  private_key BLOB;  
  PRIVATE_KEY_PASSWORD VARCHAR2(500);  
begin
    DBMS_LOB.createtemporary(PRIVATE_KEY, true);
    private_key_handle := BFILENAME('SSH_KEYS_DIR', 'test_putty_private.ppk'); -- directory name must be Upper case
    DBMS_LOB.OPEN(private_key_handle, DBMS_LOB.LOB_READONLY);
    DBMS_LOB.LoadFromFile( private_key, private_key_handle, DBMS_LOB.GETLENGTH(private_key_handle) );
    DBMS_LOB.CLOSE(private_key_handle);
    PRIVATE_KEY_PASSWORD := 'changeit';
  
    connection_id := ORA_SFTP.CONNECT_HOST('localhost', 22, 'nasko', private_key, private_key_password);

    ORA_SFTP.CD(connection_id, 'Log');
    
    if ORA_SFTP.IS_DIRECTORY(connection_id, 'Logs') then
      ORA_SFTP.CD(connection_id, 'Logs');
    end if;
    dbms_output.put_line(ORA_SFTP.CURRENT_DIRECTORY(connection_id));
    
    -- go one directory up
    ORA_SFTP.CD_UP(connection_id);
    dbms_output.put_line(ORA_SFTP.CURRENT_DIRECTORY(connection_id));
      
    ORA_SFTP.DISCONNECT_HOST(connection_id);  
EXCEPTION
  WHEN OTHERS THEN
   DBMS_OUTPUT.PUT_LINE('General error : ' || SQLERRM );
end;
/

