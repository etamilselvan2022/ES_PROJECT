------------------------------------------------------
-- Demonstrates the usage of ORA_PGP.IS_TRIAL_VERSION
--
-- (c) Copyright DidiSoft Inc Eood, 2006
------------------------------------------------------
begin
  if ORA_SFTP.IS_TRIAL_VERSION = 1 then
    DBMS_OUTPUT.PUT_LINE('The package is an Evaluation (Trial) Version');
  else 
    DBMS_OUTPUT.PUT_LINE('The package is a Registered Production Version');
  end if;
end;
/
exit;