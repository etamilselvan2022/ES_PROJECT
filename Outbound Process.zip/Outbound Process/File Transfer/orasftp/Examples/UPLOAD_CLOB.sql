--------------------------------
-- UPLOAD.sql
--
-- SFTP file upload example
--
-- Copyright (c) DidiSoft Inc, 2018
--------------------------------
declare 
  connection_id number;  
  private_key_handle BFILE;
  private_key BLOB;  
  private_key_password VARCHAR2(500);  
  
  cdata CLOB;
  
begin
        DBMS_JAVA.set_output(1000);  

    DBMS_LOB.createtemporary(PRIVATE_KEY, true);
    private_key_handle := BFILENAME('ORACLE_HOME', 'private_sshcom_no_pass.txt'); -- directory name must be Upper case
    
    -- load the data into a BLOB
    DBMS_LOB.OPEN(private_key_handle, DBMS_LOB.LOB_READONLY);
    DBMS_LOB.LoadFromFile( private_key, private_key_handle, DBMS_LOB.GETLENGTH(private_key_handle) );
    DBMS_LOB.CLOSE(private_key_handle);
    private_key_password := 'changeit';
    private_key_password := '';
    connection_id := ORA_SFTP.CONNECT_HOST('localhost', 22, 'nasko', private_key, private_key_password);
  
    -- usually we will SELECT INTO cdata 
    select note into cdata from recipients
    where name = 'nasko';
    
    ORA_SFTP.UPLOAD_CLOB(connection_id, cdata, 'cdata3.txt', 1024, 'UTF-16');
    
    ORA_SFTP.DISCONNECT_HOST(connection_id);
end;
/
