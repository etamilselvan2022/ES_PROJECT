------------------------------------------------------
-- DidisSoft ORA_INET examples
--
-- Demonstrates the usage of ORA_NET.WGET 
-- quick download of Web resources
--
-- (c) Copyright DidiSoft Inc Eood, 2019
------------------------------------------------------
declare
 blob_file BLOB;
begin  
 blob_file := ORA_NET.WGET('https://www.didisoft.com/robots.txt');
 dbms_output.put_line(UTL_RAW.CAST_TO_VARCHAR2(blob_file));
END;
/
