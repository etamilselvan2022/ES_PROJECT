------------------------------------------------------
-- DidisSoft ORA_INET examples
--
-- Demonstrates the usage of ORA_NET.WGET 
-- quick download of Web resources
--
-- (c) Copyright DidiSoft Inc Eood, 2019
------------------------------------------------------
declare
 blob_file BLOB;
 err VARCHAR(2000);
 res INTEGER;
begin  
 res := ORA_NET.WGET('https://www.didisoft.com/robots.txt', blob_file, err);
 
 IF res = ORA_NET.SUCCESS THEN
   dbms_output.put_line(UTL_RAW.CAST_TO_VARCHAR2(blob_file));
 ELSE 
   dbms_output.put_line(err);
 END IF;
END;
/
