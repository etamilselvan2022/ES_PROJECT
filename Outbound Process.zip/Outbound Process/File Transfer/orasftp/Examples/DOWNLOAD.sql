---------------------------------------------------
-- DidiSoft OraSFTP - SFTP communication for PL/SQL
-- DOWNLOAD.sql
-- Copyright (c) DidiSoft Inc Eood, 2006-2021 
---------------------------------------------------
declare 
  connection_id number;
  private_key_handle BFILE;
  private_key BLOB;  
  private_key_password VARCHAR2(500);  
  downloaded_file BLOB;
  sftp_username VARCHAR2(255);
begin
    private_key_handle := BFILENAME('ORACLE_HOME', 'private_sshcom_no_pass.txt'); -- directory name must be Upper case
    
    DBMS_LOB.createtemporary(private_key, true);
    DBMS_LOB.OPEN(private_key_handle, DBMS_LOB.LOB_READONLY);
    DBMS_LOB.LoadFromFile( private_key, private_key_handle, DBMS_LOB.GETLENGTH(private_key_handle) );
    DBMS_LOB.CLOSE(private_key_handle);
    private_key_password := 'changeit';
  
    sftp_username := 'nasko';
    connection_id := ORA_SFTP.CONNECT_HOST('localhost', 22, sftp_username, private_key, private_key_password);

    downloaded_file := ORA_SFTP.DOWNLOAD(connection_id, 'TrustLevel.cs');

    ORA_SFTP.DISCONNECT_HOST(connection_id);
    
end;
/
