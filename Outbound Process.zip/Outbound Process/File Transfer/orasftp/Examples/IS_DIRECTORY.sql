declare 
  connection_id number;  
  private_key_handle BFILE;
  private_key BLOB;  
  PRIVATE_KEY_PASSWORD VARCHAR2(500);  
begin
    DBMS_LOB.createtemporary(PRIVATE_KEY, true);
    private_key_handle := BFILENAME('PGP_KEYS_DIR', 'test_putty_private.ppk'); -- directory name must be Upper case
    DBMS_LOB.OPEN(private_key_handle, DBMS_LOB.LOB_READONLY);
    DBMS_LOB.LoadFromFile( private_key, private_key_handle, DBMS_LOB.GETLENGTH(private_key_handle) );
    DBMS_LOB.CLOSE(private_key_handle);
    PRIVATE_KEY_PASSWORD := 'changeit';
  
    connection_id := ORA_SFTP.CONNECT_HOST('localhost', 22, 'nasko', private_key, private_key_password);
  
    if ORA_SFTP.IS_DIRECTORY(connection_id, 'NewFolder') then
    begin
        DBMS_OUTPUT.PUT_LINE('it is a directory');        
    end;
  end if;
  
    ORA_SFTP.DISCONNECT_HOST(connection_id);  
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
     IF INSTR (SQLERRM, 'SFTPException') = 0
     THEN
        DBMS_OUTPUT.PUT_LINE('SFTP error : ' || SQLERRM );
     ELSE     
        DBMS_OUTPUT.PUT_LINE('General error : ' || SQLERRM );
     END IF;
   END;
end;
/
