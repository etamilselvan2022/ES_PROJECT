declare 
  files ORA_SFTP_FILES_LIST_EX;
  connection_id number;  
  private_key_handle BFILE;
  private_key BLOB;  
  PRIVATE_KEY_PASSWORD VARCHAR2(500);  
begin
    DBMS_LOB.createtemporary(PRIVATE_KEY, true);
    private_key_handle := BFILENAME('SSH_KEYS_DIR', 'test_putty_private.ppk'); -- directory name must be Upper case
    DBMS_LOB.OPEN(private_key_handle, DBMS_LOB.LOB_READONLY);
    DBMS_LOB.LoadFromFile( private_key, private_key_handle, DBMS_LOB.GETLENGTH(private_key_handle) );
    DBMS_LOB.CLOSE(private_key_handle);
    PRIVATE_KEY_PASSWORD := 'changeit';
  
    connection_id := ORA_SFTP.CONNECT_HOST('localhost', 22, 'nasko', private_key, private_key_password);
  
    -- all files from current folder ( ORA_SFTP.PWD )
    files := ORA_SFTP.LIST_EX(connection_id, ORA_SFTP.ORDER_NAME_ASC, '*');  
    
    -- print the listed file names   
    for i in files.first .. files.last loop
     dbms_output.put_line('file(' || i || ') = ' || files(i).FileName || ' ' || files(i).FileSize || ' bytes');
    end loop;

    ORA_SFTP.DISCONNECT_HOST(connection_id);  
EXCEPTION
  WHEN OTHERS THEN
   DBMS_OUTPUT.PUT_LINE('General error : ' || SQLERRM );
end;
/
