------------------------------------------------------
-- Demonstrates the usage of ORA_SFTP.CONNECT_HOST
--
-- (c) Copyright DidiSoft Inc Eood, 2006
------------------------------------------------------
declare 
 connection_id NUMBER;
 remote_ssh_port NUMBER := 22;
 username VARCHAR2(200);
 password VARCHAR2(200); 
begin
 username:= 'myuser'; 
 password:= 'mypass';
 connection_id := ORA_SFTP.CONNECT_HOST('localhost', remote_ssh_port, username, password);
 ORA_SFTP.DISCONNECT_HOST(connection_id);
end;
/
