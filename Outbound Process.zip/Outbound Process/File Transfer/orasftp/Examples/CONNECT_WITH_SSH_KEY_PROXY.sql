------------------------------------------------------
-- Demonstrates the usage of ORA_SFTP.CONNECT_HOST_PROXY 
-- with SSH private key 
-- 
-- The connection is made trhough an HTTP proxy running on localhost
--
-- (c) Copyright DidiSoft Inc Eood, 2006 - 2021
------------------------------------------------------
declare 
  connection_id number;
  proxy ORA_SFTP_HTTP_PROXY;
  
  private_key_handle BFILE;
  private_key BLOB;  
  private_key_password VARCHAR2(500);  
  private_key_file_name VARCHAR2(500);

begin
    -- initialize the key storage
    DBMS_LOB.createtemporary(private_key, true);
    
    private_key_file_name := 'private_sshcom_no_pass.txt';    
    private_key_password := 'changeit';    
    -- the direcory name must be created with CREATE DIRECTORY SSH_KEYS_DIR AS '/demo/schema/my_data_folder';
    private_key_handle := BFILENAME('ORACLE_HOME', private_key_file_name);
    
    -- load the data into a BLOB
    DBMS_LOB.OPEN(private_key_handle, DBMS_LOB.LOB_READONLY);
    DBMS_LOB.LoadFromFile( DEST_LOB => private_key,
                         SRC_LOB  => private_key_handle,
                         AMOUNT   => DBMS_LOB.GETLENGTH(private_key_handle) );
    DBMS_LOB.CLOSE(private_key_handle);

    --prop_result := dbms_java.set_property('java.net.preferIPv4Stack','true');
    -- OK, this is just a test, we run a local HTTP Proxy on port 8000 and our test SFTP server is on port 22
    -- in a real world scenario your Proxy and SFTP servers probably won't be on the same machine :)
    proxy := ORA_SFTP_HTTP_PROXY(Address => 'localhost', Port => 8000, Username => NULL, Password => NULL, AdditionalHeaders => NULL);

    connection_id := ORA_SFTP.CONNECT_HOST_PROXY('localhost', 22, 'nasko', private_key, '', proxy => proxy);
    ORA_SFTP.DISCONNECT_HOST(connection_id);
end;

