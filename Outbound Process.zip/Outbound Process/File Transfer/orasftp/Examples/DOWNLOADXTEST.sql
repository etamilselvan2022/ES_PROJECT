---------------------------------------------------
-- DidiSoft OraSFTP - SFTP communication for PL/SQL
-- DOWNLOAD.sql
-- Copyright (c) DidiSoft Inc Eood, 2006-2021 
---------------------------------------------------
declare 
  connection_id number;
  private_key_handle BFILE;
  private_key BLOB;  
  private_key_password VARCHAR2(500);  
  downloaded_file BLOB;
  sftp_username VARCHAR2(255);
begin
     Dbms_Output.enable(100000);
        DBMS_JAVA.set_output(100000);
     ORA_SFTP.SET_DEBUG(false);
  

--    private_key_handle := BFILENAME('PGP_KEYS_DIR', 'test_putty_private.ppk');
    private_key_handle := BFILENAME('ORACLE_HOME', 'private_sshcom_no_pass.txt'); -- directory name must be Upper case
    
    DBMS_LOB.createtemporary(private_key, true);
    DBMS_LOB.OPEN(private_key_handle, DBMS_LOB.LOB_READONLY);
    DBMS_LOB.LoadFromFile( private_key, private_key_handle, DBMS_LOB.GETLENGTH(private_key_handle) );
    DBMS_LOB.CLOSE(private_key_handle);
    private_key_password := 'changeit';
  
    sftp_username := 'nasko';
    
FOR loop_counter IN 1..100
LOOP
    connection_id := ORA_SFTP.CONNECT_HOST('localhost', 22, 'nasko', private_key, private_key_password);

    downloaded_file := ORA_SFTP.DOWNLOAD(connection_id, 'TrustLevel.cs');
    ORA_SFTP.UPLOAD(connection_id,  private_key, 'private_sshcom_no_pass.txt');

    ORA_SFTP.DISCONNECT_HOST(connection_id);
   
END LOOP;
    
end;
/
