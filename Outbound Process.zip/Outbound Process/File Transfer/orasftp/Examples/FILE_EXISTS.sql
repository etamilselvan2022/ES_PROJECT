--------------------------------
-- FILE_EXISTS.sql
--
-- SSH file/folder check example
--
-- Copyright (c) DidiSoft Inc, 2021
--------------------------------
declare 
  connection_id number;  
  private_key_handle BFILE;
  private_key BLOB;  
  PRIVATE_KEY_PASSWORD VARCHAR2(500);  
begin
    DBMS_LOB.createtemporary(PRIVATE_KEY, true);
    --private_key_handle := BFILENAME('SSH_KEYS_DIR', 'test_putty_private.ppk'); -- directory name must be Upper case
	private_key_handle := BFILENAME('SSH_KEYS_DIR', 'private_sshcom_no_pass.txt'); -- directory name must be Upper case
    DBMS_LOB.OPEN(private_key_handle, DBMS_LOB.LOB_READONLY);
    DBMS_LOB.LoadFromFile( private_key, private_key_handle, DBMS_LOB.GETLENGTH(private_key_handle) );
    DBMS_LOB.CLOSE(private_key_handle);
    PRIVATE_KEY_PASSWORD := 'changeit';
  
    connection_id := ORA_SFTP.CONNECT_HOST('localhost', 22, 'nasko', private_key, private_key_password);
  
    if ORA_SFTP.EXISTS(connection_id, 'MyPictire.jpg') then
      dbms_output.put_line('MyPictire.jpg exists!');
    else   
      dbms_output.put_line('MyPictire.jpg does not exists!');
    end if;
  
    ORA_SFTP.DISCONNECT_HOST(connection_id);  
EXCEPTION
  WHEN OTHERS THEN
   DBMS_OUTPUT.PUT_LINE('General error : ' || SQLERRM );
end;
/
