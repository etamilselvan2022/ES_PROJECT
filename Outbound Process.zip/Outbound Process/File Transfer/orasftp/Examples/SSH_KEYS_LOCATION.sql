---------------------------------------------------------------
-- DidiSoft OraSFTP Examples
--
-- Initial setup - create directory pointer for SSH keys location
---------------------------------------------------------------
CREATE DIRECTORY MY_KEYS_DIR AS '[OraSFTP extraction folder path]/Examples';
