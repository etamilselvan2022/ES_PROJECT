declare 
  connection_id number;  
  private_key_handle BFILE;
  private_key BLOB;  
  PRIVATE_KEY_PASSWORD VARCHAR2(500);  
  
begin
    DBMS_LOB.createtemporary(PRIVATE_KEY, true);
    private_key_handle := BFILENAME('PGP_KEYS_DIR', 'test_putty_private.ppk'); -- directory name must be Upper case
    DBMS_LOB.OPEN(private_key_handle, DBMS_LOB.LOB_READONLY);
    DBMS_LOB.LoadFromFile( private_key, private_key_handle, DBMS_LOB.GETLENGTH(private_key_handle) );
    DBMS_LOB.CLOSE(private_key_handle);
    PRIVATE_KEY_PASSWORD := 'changeit';
  
    connection_id := ORA_SFTP.CONNECT_HOST('localhost', 22, 'nasko', private_key, private_key_password);
  
    DBMS_OUTPUT.PUT_LINE('File size is ' ||
                         ORA_SFTP.FILE_SIZE(connection_id, '10.155.17.211_SMTP_via_LDAP_12-11-2015_11-34-04.pdf')
                         || ' bytes');  
  
    ORA_SFTP.DISCONNECT_HOST(connection_id);  
end;
/
