------------------------------------------------------
-- Demonstrates the usage of ORA_SFTP.CONNECT_HOST 
-- with both SSH private key and server account password
--
-- (c) Copyright DidiSoft Inc Eood, 2006 - 2021
------------------------------------------------------
declare 
  connection_id number;
  
  private_key_handle BFILE;
  private_key BLOB;  
  private_key_password VARCHAR2(500);  
  private_key_file_name VARCHAR2(500);
  
  username VARCHAR2(500);  
  user_password VARCHAR2(500);    
begin
    -- initialize the key storage
    DBMS_LOB.createtemporary(private_key, true);
    
    private_key_file_name := 'private_sshcom_no_pass.txt';    
    private_key_password := '';    
    -- the direcory name must be created with CREATE DIRECTORY SSH_KEYS_DIR AS '/demo/schema/my_data_folder';
    private_key_handle := BFILENAME('ORACLE_HOME', private_key_file_name); -- directory name must be Upper case
    
    -- load the data into a BLOB
    DBMS_LOB.OPEN(private_key_handle, DBMS_LOB.LOB_READONLY);
    DBMS_LOB.LoadFromFile( DEST_LOB => private_key,
                         SRC_LOB  => private_key_handle,
                         AMOUNT   => DBMS_LOB.GETLENGTH(private_key_handle) );
    DBMS_LOB.CLOSE(private_key_handle);
  
    username := 'nasko';
    user_password := 'nasko';
        
    connection_id := ORA_SFTP.CONNECT_WITH_KEY_AND_PASSWORD('localhost', 22, username, user_password, private_key, private_key_password);
    ORA_SFTP.DISCONNECT_HOST(connection_id);
end;

