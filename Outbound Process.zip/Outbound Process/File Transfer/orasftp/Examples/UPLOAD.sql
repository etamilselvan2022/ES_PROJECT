--------------------------------
-- UPLOAD.sql
--
-- SFTP file upload example
--
-- Copyright (c) DidiSoft Inc, 2018
--------------------------------
declare 
  connection_id number;  
  private_key_handle BFILE;
  private_key BLOB;  
  PRIVATE_KEY_PASSWORD VARCHAR2(500);  
begin
    DBMS_LOB.createtemporary(PRIVATE_KEY, true);
    private_key_handle := BFILENAME('SSH_KEYS_DIR', 'test_putty_private.ppk'); -- directory name must be Upper case
    
    -- load the data into a BLOB
    DBMS_LOB.OPEN(private_key_handle, DBMS_LOB.LOB_READONLY);
    DBMS_LOB.LoadFromFile( private_key, private_key_handle, DBMS_LOB.GETLENGTH(private_key_handle) );
    DBMS_LOB.CLOSE(private_key_handle);
    PRIVATE_KEY_PASSWORD := 'changeit';
  
    connection_id := ORA_SFTP.CONNECT_HOST('localhost', 22, 'nasko', private_key, private_key_password);
  
    ORA_SFTP.UPLOAD(connection_id, private_key, 'private_key.txt');
    
    ORA_SFTP.DISCONNECT_HOST(connection_id);
end;
/
