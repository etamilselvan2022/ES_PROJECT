------------------------------------------------------
-- Demonstrates the usage of ORA_SFTP.TOUCH_LOCAL 
--
-- (c) Copyright DidiSoft Inc Eood, 2006
------------------------------------------------------
begin
    ORA_SFTP.TOUCH_LOCAL('c:\Projects\PGPKeys\public.key', TO_TIMESTAMP ('10-Sep-02 14:10:10', 'DD-Mon-RR HH24:MI:SS'));    
end;
/
