BEGIN
  DBMS_NETWORK_ACL_ADMIN.create_acl (
    acl          => 'ESCORTS ERP-ESCORTS SFTP PROCESS.xml', 
    description  => 'ERP-SFTP',
    principal    => 'APPS',
    is_grant     => TRUE, 
    privilege    => 'connect',
    start_date   => SYSTIMESTAMP,
    end_date     => NULL);

  COMMIT;
END;

BEGIN
  DBMS_NETWORK_ACL_ADMIN.assign_acl (
    acl         => 'ESCORTS ERP-ESCORTS SFTP PROCESS.xml',
    host        => '192.168.16.62', 
    lower_port  => NULL,
    upper_port  => NULL);

  COMMIT;
END;

call dbms_java.grant_permission( 'APPS', 'SYS:java.net.SocketPermission', '192.168.16.62', 'connect,resolve' );
commit;

