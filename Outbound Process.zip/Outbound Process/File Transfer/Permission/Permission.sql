BEGIN
   DBMS_JAVA.grant_permission ('APPS',
                               'SYS:java.io.FilePermission',
                               '/orahome/app/oraerp/19.3.0/demand/data/out/src',
                               'read ,write, execute, delete');
   DBMS_JAVA.grant_permission ('APPS',
                               'SYS:java.io.FilePermission',
                               '/orahome/app/oraerp/19.3.0/demand/data/out/src/*',
                               'read ,write, execute, delete');
END;
-------------------------------------------------------------------------------------------
BEGIN
   DBMS_JAVA.grant_permission ('APPS',
                               'SYS:java.io.FilePermission',
                               '/orahome/app/oraerp/19.3.0/demand/data/out/bkp',
                               'read ,write, execute, delete');
   DBMS_JAVA.grant_permission ('APPS',
                               'SYS:java.io.FilePermission',
                               '/orahome/app/oraerp/19.3.0/demand/data/out/bkp/*',
                               'read ,write, execute, delete');
END;

----------------------------------------------------------------------------------------------------------
exec dbms_java.grant_permission( 'APPS','SYS:java.lang.RuntimePermission', 'writeFileDescriptor', '' );
exec dbms_java.grant_permission( 'APPS','SYS:java.lang.RuntimePermission', 'readFileDescriptor', '' );
----------------------------------------------------------------------------------------------------------