CREATE OR REPLACE AND COMPILE JAVA SOURCE NAMED "XXes_ExecuteCmd" AS

import java.lang.Runtime;

import java.lang.Process;

import java.io.IOException;

import java.lang.InterruptedException;



class ExecuteCmd {



  public static void main(String args[]) {



  System.out.println("In main");



  try {

  /* Execute the command using the Runtime object and get the

  Process which controls this command */



  Process p = Runtime.getRuntime().exec(args[0]);



  /* Use the following code to wait for the process to finish

  and check the return code from the process */

  try {



  p.waitFor();

  

  /* Handle exceptions for waitFor() */



  } catch (InterruptedException intexc) {



  System.out.println("Interrupted Exception on waitFor: " + intexc.getMessage());

  }



  System.out.println("Return code from process"+ p.exitValue());



  System.out.println("Done executing");

  

  /* Handle the exceptions for exec() */

  } catch (IOException e) {

  System.out.println("IO Exception from exec : " +

  e.getMessage());

  e.printStackTrace();

  }

  }

}
/

--------------------------------------------------------------------------------------------------------------------------------------------------
create or replace PROCEDURE xxes_executecmd_prc (p_file VARCHAR2) AS LANGUAGE JAVA
name 'ExecuteCmd.main(java.lang.String[])';
-------------------------------------------------------------------------------------
exec dbms_java.grant_permission( 'APPS', 'SYS:java.io.FilePermission',
'<<ALL FILES>>','execute');
exec dbms_java.grant_permission( 'APPS',
'SYS:java.lang.RuntimePermission', 'writeFileDescriptor', '' );
exec dbms_java.grant_permission( 'APPS',
'SYS:java.lang.RuntimePermission', 'readFileDescriptor', '' );
------------------------------------------------------------------------